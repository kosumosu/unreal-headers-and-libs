/*=============================================================================
	ACarcass.h.
	Copyright 1997-1999 Epic Games, Inc. All Rights Reserved.
=============================================================================*/

	// Constructors.
	ACarcass() {}

	// AActor interface.
	virtual FLOAT UpdateFrequency(AActor *Viewer, FVector &ViewDir, FVector &ViewPos);

/*-----------------------------------------------------------------------------
	The End.
-----------------------------------------------------------------------------*/
