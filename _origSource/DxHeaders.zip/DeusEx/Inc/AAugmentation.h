// ----------------------------------------------------------------------
//  File Name   :  AAugmentation.h
//  Programmer  :  Alex Duran
//  Description :  Header for Augmentation class
// ----------------------------------------------------------------------
//  Copyright �2000 ION Storm Austin.  This software is a trade secret.
// ----------------------------------------------------------------------

//
// End.
//