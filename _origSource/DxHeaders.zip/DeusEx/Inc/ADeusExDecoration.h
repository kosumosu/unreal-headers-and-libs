// ----------------------------------------------------------------------
//  File Name   :  ADeusExDecoration.h
//  Programmer  :  Scott Martin
//  Description :  Header for DeusExDecoration class
// ----------------------------------------------------------------------
//  Copyright �1999 ION Storm Austin.  This software is a trade secret.
// ----------------------------------------------------------------------

	// Constructor
	void ConBindEvents(void);
	void BindConversations(void);
	void BindEvents(void);
