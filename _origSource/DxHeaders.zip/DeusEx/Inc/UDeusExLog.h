// ----------------------------------------------------------------------
//  File Name   :  UDeusExLog.h
//  Programmer  :  Scott Martin
//  Description :  DeusEx Log Information
// ----------------------------------------------------------------------
//  Copyright �1999 ION Storm Austin.  This software is a trade secret.
// ----------------------------------------------------------------------

	// Constructor
	UDeusExLog() : UObject() {}

