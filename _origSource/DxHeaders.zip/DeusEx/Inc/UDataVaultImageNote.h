// ----------------------------------------------------------------------
//  File Name   :  UDataVaultImageNote.h
//  Programmer  :  Albert Yarusso
//  Description :  DeusEx Level Map Note 
// ----------------------------------------------------------------------
//  Copyright �1999 ION Storm Austin.  This software is a trade secret.
// ----------------------------------------------------------------------

	// Constructor
	UDataVaultImageNote() : UObject() {}

