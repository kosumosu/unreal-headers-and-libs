// ----------------------------------------------------------------------
//  File Name   :  ADeusExLevelInfo.h
//  Programmer  :  Scott Martin
//  Description :  DeusEx Level Information
// ----------------------------------------------------------------------
//  Copyright �1999 ION Storm Austin.  This software is a trade secret.
// ----------------------------------------------------------------------

	// Constructor
	ADeusExLevelInfo();
