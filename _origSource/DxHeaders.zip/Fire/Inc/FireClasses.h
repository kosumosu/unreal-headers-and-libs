/*===========================================================================
	C++ class definitions exported from UnrealEd.
===========================================================================*/
#pragma pack (push,4) /* 4-byte alignment */

#pragma pack (pop) /* Restore alignment to previous setting */
