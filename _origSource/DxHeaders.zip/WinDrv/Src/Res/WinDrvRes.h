//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinDrvRes.rc
//
#define IDCURSOR_CameraZoom             101
#define IDCURSOR_BrushFree              102
#define IDCURSOR_BrushMove              103
#define IDCURSOR_BrushRot               104
#define IDCURSOR_BrushScale             105
#define IDCURSOR_BrushSheer             106
#define IDCURSOR_BrushStretch           107
#define IDCURSOR_SelectPolys            108
#define IDCURSOR_SelectActors           109
#define IDCURSOR_AddActor               110
#define IDCURSOR_TexSet                 111
#define IDCURSOR_TexGrab                112
#define IDCURSOR_TexPan                 113
#define IDCURSOR_TexScale               114
#define IDCURSOR_TexRot                 115
#define IDCURSOR_MoveActor              116
#define IDCURSOR_Terraform              121
#define IDCURSOR_BrushWarp              122
#define IDCURSOR_BrushSnap              123
#define IDICON_MAINFRAME                128
#define ID_DDMode0                      140
#define ID_DDMode1                      141
#define ID_DDMode2                      142
#define ID_DDMode3                      143
#define ID_DDMode4                      144
#define ID_DDMode5                      145
#define ID_DDMode6                      146
#define ID_DDMode7                      147
#define ID_DDMode8                      148
#define ID_DDMode9                      149
#define IDMENU_PlayerCam                155
#define IDMENU_EditorCam                156
#define ID_MapDynLight                  200
#define ID_MapWire                      202
#define ID_MapPolyCuts                  203
#define ID_MapPolys                     204
#define ID_MapOverhead                  207
#define ID_MapXZ                        208
#define ID_MapYZ                        209
#define ID_ShowBrush                    212
#define ID_ShowBackdrop                 253
#define ID_ActorsShow                   255
#define ID_FileExit                     32775
#define ID_ViewTop                      32817
#define ID_Win320                       32818
#define ID_Win400                       32819
#define ID_Win640                       32822
#define ID_Win512                       32832
#define ID_ViewAdvanced                 32838
#define ID_Color16Bit                   32840
#define ID_Color32Bit                   32841
#define ID_ShowMovingBrushes            32846
#define ID_ActorsIcons                  32847
#define ID_ActorsRadii                  32848
#define ID_ActorsHide                   32849
#define ID_ShowPaths                    32850
#define ID_Win800                       32852
#define ID_ShowCoords                   40003
#define ID_MapPlainTex                  40016
#define ID_ViewLog                      40028
#define ID_MapZones                     40029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           112
#endif
#endif
